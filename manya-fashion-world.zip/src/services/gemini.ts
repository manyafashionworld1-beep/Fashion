import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function getStylingAdvice(userPrompt: string, availableProducts: any[]) {
  const prompt = `
    You are an expert AI Fashion Stylist for "Manya Fashion World", a premium luxury fashion store.
    
    The user is asking: "${userPrompt}"
    
    Here are some products currently in stock:
    ${JSON.stringify(availableProducts.map(p => ({ name: p.name, description: p.description, category: p.category })))}
    
    Provide styling advice that incorporates these products. Be elegant, persuasive, and sophisticated.
    Format your response in Markdown. Suggest at least 2-3 specific products.
  `;

  try {
    const result = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return result.text || "I'm sorry, I couldn't generate advice right now.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I'm having trouble connecting to my styling database right now. Please try again later!";
  }
}
