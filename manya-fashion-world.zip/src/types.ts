export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'Men' | 'Women' | 'Kids' | 'Accessories';
  images: string[];
  sizes: string[];
  colors: string[];
  stock: number;
  featured?: boolean;
}

export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  wishlist: string[]; // array of product IDs
}

export interface Order {
  id: string;
  userId: string;
  items: {
    productId: string;
    quantity: number;
    price: number;
    size?: string;
    color?: string;
  }[];
  totalAmount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
}
