import { useState, useEffect } from 'react';
import { ShoppingBag, Search, User, Menu, X, Sparkles, ArrowRight, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db, auth } from './lib/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { MOC_PRODUCTS } from './constants';
import { getStylingAdvice } from './services/gemini';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState('All');
  const [cartCount, setCartCount] = useState(0);
  const [isAiStylistOpen, setIsAiStylistOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [user, setUser] = useState<FirebaseUser | null>(null);

  useEffect(() => {
    // Test Firestore connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();

    // Auth listener
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });
    return () => unsubscribe();
  }, []);

  const filteredProducts = activeCategory === 'All' 
    ? MOC_PRODUCTS 
    : MOC_PRODUCTS.filter(p => p.category === activeCategory);

  const handleAiStylist = async () => {
    if (!aiPrompt) return;
    setIsTyping(true);
    setAiResponse('');
    const response = await getStylingAdvice(aiPrompt, MOC_PRODUCTS);
    setAiResponse(response);
    setIsTyping(false);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#E5E5E5] font-sans selection:bg-white selection:text-black">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-[#0A0A0A]/90 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex justify-between items-center h-24">
            <div className="flex-shrink-0 flex items-center">
              <span className="text-3xl font-serif font-bold tracking-[0.2em] uppercase text-white">Manya</span>
              <span className="ml-3 text-[10px] font-bold tracking-[0.4em] uppercase text-zinc-500 hidden lg:block">Atelier Paris</span>
            </div>
            
            <div className="hidden md:flex space-x-12 items-center">
              {['All', 'Women', 'Men', 'Accessories'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`text-[10px] font-bold tracking-[0.3em] uppercase transition-all hover:text-white ${activeCategory === cat ? 'text-white border-b border-white pb-1' : 'text-zinc-500'}`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="flex items-center space-x-6">
              <button className="p-2 text-zinc-400 hover:text-white transition-colors">
                <Search size={18} strokeWidth={1.5} />
              </button>
              <button className="p-2 text-zinc-400 hover:text-white transition-colors relative">
                <ShoppingBag size={18} strokeWidth={1.5} />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-white text-black text-[9px] w-4 h-4 flex items-center justify-center rounded-full font-bold">
                    {cartCount}
                  </span>
                )}
              </button>
              <button className="p-2 text-zinc-400 hover:text-white transition-colors">
                <User size={18} strokeWidth={1.5} />
              </button>
              <button 
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden p-2 text-zinc-400 hover:text-white transition-colors"
              >
                {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#0A0A0A] border-b border-white/10 overflow-hidden"
          >
            <div className="px-6 pt-2 pb-8 space-y-6">
              {['All', 'Women', 'Men', 'Accessories'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => {
                    setActiveCategory(cat);
                    setIsMenuOpen(false);
                  }}
                  className="block w-full text-left text-[11px] font-bold uppercase tracking-[0.3em] text-zinc-400 hover:text-white"
                >
                  {cat}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section className="relative h-[90vh] overflow-hidden bg-black grid md:grid-cols-12">
        <div className="md:col-span-7 relative h-full flex flex-col justify-end p-8 md:p-24 border-r border-white/10">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?q=80&w=2070&auto=format&fit=crop" 
              alt="Hero Fashion" 
              className="w-full h-full object-cover grayscale opacity-40 brightness-75 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10" />
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-20"
          >
            <h1 className="text-7xl md:text-[9rem] font-serif font-light text-white mb-8 leading-[0.85] tracking-tight">
              Define Your <br /> <span className="italic opacity-80">Essence</span>
            </h1>
            <p className="text-zinc-400 max-w-sm text-sm mb-10 font-light leading-relaxed tracking-wide">
              Discover the Atelier Collection — a symphony of structured silhouettes and fluid fabrics designed for the modern visionary.
            </p>
            <div className="flex flex-wrap gap-6">
              <button className="bg-white text-black px-12 py-5 font-bold flex items-center gap-3 hover:bg-zinc-200 transition-all uppercase tracking-[0.3em] text-[10px]">
                Explore <ArrowRight size={14} />
              </button>
              <button 
                onClick={() => setIsAiStylistOpen(true)}
                className="bg-transparent border border-white/20 text-white px-10 py-5 font-bold flex items-center gap-3 hover:bg-white/5 transition-all uppercase tracking-[0.3em] text-[10px] backdrop-blur-sm"
              >
                <Sparkles size={14} /> AI Stylist
              </button>
            </div>
          </motion.div>
        </div>

        <div className="hidden md:flex md:col-span-5 relative flex-col justify-between p-12 bg-[#050505]">
          <div className="flex justify-between items-start">
             <div className="text-[10px] uppercase tracking-[0.5em] text-zinc-600 font-bold border-l border-white/20 pl-4 py-1">
                Summer <br /> MMXVI
             </div>
             <div className="text-white/5 font-serif text-9xl absolute -right-12 top-1/2 -translate-y-1/2 rotate-90 pointer-events-none uppercase">
                Manya
             </div>
          </div>
          
          <div className="relative group cursor-pointer overflow-hidden aspect-[4/5] bg-zinc-900 border border-white/5">
             <img 
               src="https://images.unsplash.com/photo-1539109132381-31a1C974a0fd?q=80&w=2070&auto=format&fit=crop" 
               className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000 grayscale brightness-75"
               alt="Aesthetic detail"
               referrerPolicy="no-referrer"
             />
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border border-white/20 flex items-center justify-center backdrop-blur-sm group-hover:scale-110 transition-transform">
                   <ArrowRight size={20} className="text-white" />
                </div>
             </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-6 md:px-12 py-32">
        <div className="flex justify-between items-end mb-20 border-b border-white/5 pb-8">
          <div>
            <p className="text-zinc-600 uppercase tracking-[0.5em] text-[10px] font-bold mb-4">The Selection</p>
            <h2 className="text-5xl font-serif text-white tracking-tight">Curated Pieces</h2>
          </div>
          <button className="text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-400 hover:text-white transition-colors border-b border-zinc-700 pb-2">
            View All Archive
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-24 gap-x-12">
          {filteredProducts.map((product, idx) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.8 }}
              className="group"
            >
              <div className="relative aspect-[3/4] overflow-hidden bg-zinc-900 mb-8 border border-white/5 transition-all duration-700 group-hover:border-white/20">
                <img 
                  src={product.images[0]} 
                  alt={product.name}
                  className="w-full h-full object-cover grayscale brightness-75 transition-all duration-1000 group-hover:scale-105 group-hover:grayscale-0 group-hover:brightness-100"
                  referrerPolicy="no-referrer"
                />
                <button className="absolute top-6 right-6 p-4 bg-[#0A0A0A]/40 backdrop-blur-md border border-white/10 rounded-full opacity-0 group-hover:opacity-100 transition-all hover:bg-white hover:text-black">
                  <Heart size={16} strokeWidth={1.5} />
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setCartCount(prev => prev + 1);
                  }}
                  className="absolute bottom-0 left-0 right-0 bg-white text-black py-6 translate-y-full group-hover:translate-y-0 transition-transform font-bold uppercase tracking-[0.3em] text-[9px]"
                >
                  Acquire Piece
                </button>
              </div>
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[9px] text-zinc-600 uppercase tracking-[0.4em] font-bold mb-3">{product.category}</p>
                  <h3 className="text-lg font-light text-white tracking-wide">{product.name}</h3>
                  <p className="text-xs text-zinc-500 italic mt-1 font-serif">Limited Release</p>
                </div>
                <p className="font-light text-zinc-300 tracking-widest">${product.price.toFixed(2)}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Brand Story / Split Section */}
      <section className="bg-black text-white grid md:grid-cols-2 border-t border-white/5">
        <div className="p-12 md:p-24 flex flex-col justify-center border-r border-white/5">
          <span className="text-[10px] font-bold uppercase tracking-[0.5em] mb-8 text-zinc-500">The Manifesto</span>
          <h2 className="text-5xl md:text-7xl font-serif mb-10 leading-[0.9] tracking-tight">
            Crafting a story <br /> through <span className="italic">fluidity</span>.
          </h2>
          <p className="border-l border-white/20 pl-8 text-zinc-400 mb-12 max-w-sm font-light leading-relaxed tracking-wide">
            Manya Fashion World was founded on the principle that luxury should be felt, not just seen. We partner with the finest ateliers to bring you pieces that transcend seasons.
          </p>
          <button className="flex items-center gap-6 group w-fit">
            <span className="w-14 h-14 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-all duration-500">
              <ArrowRight size={20} strokeWidth={1} />
            </span>
            <span className="uppercase tracking-[0.4em] text-[10px] font-bold text-zinc-400 group-hover:text-white transition-colors">Our Legacy</span>
          </button>
        </div>
        <div className="h-[600px] md:h-auto overflow-hidden bg-zinc-900 group">
          <img 
            src="https://images.unsplash.com/photo-1441996675211-16346f906560?q=80&w=2070&auto=format&fit=crop" 
            alt="Artisanal Work" 
            className="w-full h-full object-cover grayscale opacity-50 group-hover:scale-105 group-hover:grayscale-0 transition-all duration-1000"
            referrerPolicy="no-referrer"
          />
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#050505] border-t border-white/5 pt-32 pb-16">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-20 mb-32">
            <div className="col-span-1 md:col-span-2">
              <span className="text-4xl font-serif font-bold tracking-[0.3em] uppercase block mb-10 text-white">Manya</span>
              <p className="text-zinc-500 max-w-xs mb-12 leading-relaxed tracking-wide font-light">
                Join our circle for exclusive early access to our seasonal archives and atelier journals.
              </p>
              <div className="relative max-w-sm group">
                <input 
                  type="email" 
                  placeholder="Journal Subscription" 
                  className="w-full bg-transparent border-b border-white/10 py-5 focus:outline-none placeholder:text-zinc-700 text-white text-sm tracking-widest focus:border-white transition-colors"
                />
                <button className="absolute right-0 bottom-5 text-zinc-500 hover:text-white uppercase tracking-[0.3em] text-[10px] font-bold transition-colors">Subscribe</button>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-[10px] uppercase tracking-[0.5em] mb-10 text-zinc-600">The House</h4>
              <ul className="space-y-6 text-xs text-zinc-400 tracking-widest">
                <li className="hover:text-white cursor-pointer transition-colors">Women's Atelier</li>
                <li className="hover:text-white cursor-pointer transition-colors">Men's Collection</li>
                <li className="hover:text-white cursor-pointer transition-colors">Objects & Scents</li>
                <li className="hover:text-white cursor-pointer transition-colors">Our Story</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[10px] uppercase tracking-[0.5em] mb-10 text-zinc-600">Concierge</h4>
              <ul className="space-y-6 text-xs text-zinc-400 tracking-widest">
                <li className="hover:text-white cursor-pointer transition-colors">Private Styling</li>
                <li className="hover:text-white cursor-pointer transition-colors">Shipping Global</li>
                <li className="hover:text-white cursor-pointer transition-colors">Returns & Care</li>
                <li className="hover:text-white cursor-pointer transition-colors">Atelier FAQ</li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center pt-16 border-t border-white/5 gap-8">
            <p className="text-[9px] text-zinc-600 uppercase tracking-[0.5em] font-bold">
              © 2026 Manya Atelier. Crafted for the Timeless.
            </p>
            <div className="flex space-x-12">
              {['Journal', 'Film', 'Collection', 'archive'].map(social => (
                <span key={social} className="text-[9px] text-zinc-600 uppercase tracking-[0.4em] font-bold hover:text-white cursor-pointer transition-colors">
                  {social}
                </span>
              ))}
            </div>
          </div>
        </div>
      </footer>

      {/* AI Stylist Modal */}
      <AnimatePresence>
        {isAiStylistOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-[#0A0A0A] border border-white/10 rounded-2xl w-full max-w-3xl h-[85vh] flex flex-col overflow-hidden shadow-[0_0_50px_rgba(255,255,255,0.05)]"
            >
              <div className="p-8 border-b border-white/5 flex justify-between items-center bg-zinc-950">
                <div className="flex items-center gap-4">
                  <Sparkles size={24} className="text-zinc-100" />
                  <div>
                    <h3 className="font-serif text-2xl tracking-wide text-white">Atelier Stylist</h3>
                    <p className="text-[9px] uppercase tracking-[0.4em] text-zinc-600 font-bold">AI Powered Guidance</p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsAiStylistOpen(false)}
                  className="p-3 hover:bg-white/5 rounded-full transition-colors text-zinc-500 hover:text-white"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-10 space-y-8 text-[#E5E5E5] scrollbar-hide">
                {!aiResponse && !isTyping ? (
                  <div className="text-center py-20 flex flex-col items-center">
                    <div className="w-20 h-20 border border-white/10 flex items-center justify-center mb-10 rotate-45">
                      <Sparkles size={32} className="text-zinc-800 -rotate-45" />
                    </div>
                    <p className="text-zinc-300 font-serif text-3xl mb-4 italic">How shall we define your look?</p>
                    <p className="text-[10px] text-zinc-600 uppercase tracking-[0.5em] font-bold max-w-xs leading-relaxed">
                      Seek guidance for galas, travel, or the daily pursuit of elegance.
                    </p>
                  </div>
                ) : (
                  <div className="max-w-none">
                    {isTyping ? (
                      <div className="flex space-x-3 items-center justify-center py-20">
                        {[0, 0.2, 0.4].map((delay, i) => (
                          <motion.div 
                            key={i}
                            animate={{ opacity: [0.2, 1, 0.2] }} 
                            transition={{ repeat: Infinity, duration: 1.5, delay }}
                            className="w-1.5 h-1.5 bg-white rounded-full" 
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="font-light text-lg text-zinc-400 leading-[1.8] space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-1000">
                        {aiResponse}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="p-10 bg-zinc-950 border-t border-white/5">
                <div className="relative group">
                  <input 
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAiStylist()}
                    placeholder="Envision a style..."
                    className="w-full bg-transparent border border-white/10 rounded-xl pl-8 pr-16 py-5 focus:outline-none focus:border-white/40 transition-all placeholder:text-zinc-800 text-white tracking-widest text-sm"
                  />
                  <button 
                    onClick={handleAiStylist}
                    disabled={isTyping || !aiPrompt}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-3 text-zinc-500 hover:text-white transition-all disabled:opacity-20"
                  >
                    <ArrowRight size={24} strokeWidth={1} />
                  </button>
                </div>
                <div className="mt-4 flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                  {['Evening Gala', 'Modern Minimalism', 'Summer in Paris'].map(suggestion => (
                    <button 
                      key={suggestion}
                      onClick={() => setAiPrompt(suggestion)}
                      className="whitespace-nowrap text-[9px] uppercase tracking-[0.3em] font-bold text-zinc-700 hover:text-zinc-300 transition-colors border border-white/5 py-2 px-4 rounded-full"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
